﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kevin.Semprini._4i.Rubrica
{
    public enum TipiDato
    {
        Nessuno,
        Email,
        Telefono,
        Web,
    }
    public class Contatto
    {
        public int IdPersona {  get; set; } 
        public TipiDato tipo { get; set; }
        public string Valore { get; set; }

        public Contatto(Persona p)
        {
            IdPersona = p.Numero;
            tipo = TipiDato.Nessuno;
        }

        public Contatto() { }
        public Contatto(string riga)
        {
             
            string[] dati = riga.Split(';');
            


            int amoguss;
            int.TryParse(dati[0], out amoguss);
            this.IdPersona = amoguss;

            TipiDato amogus;
            Enum.TryParse(dati[1], out amogus);
            this.tipo = amogus;

            this.Valore = dati[2];
        }

        public static Contatto MakeContatto(string riga)
        {
            string[] campi = riga.Split(";");

            TipiDato c;
            Enum.TryParse(campi[1], out c);

            switch (c)
            {
                case TipiDato.Email:
                    return new ContattoEmail(riga);

                case TipiDato.Telefono:
                    return new ContattoEmail(riga);
            }


            return new Contatto(riga);
        }

    }


    public class ContattoEmail : Contatto
    {
        public ContattoEmail() { }
        public ContattoEmail(string riga) : base(riga)
        {

        }
    }


    public class Contatti : List<Contatto>
    {
        public Contatti() { }
        public Contatti(string nomeFile)
        {
            StreamReader fin = new StreamReader(nomeFile);
            fin.ReadLine();

            while (!fin.EndOfStream)
            {
                Add(Contatto.MakeContatto(fin.ReadLine()));
            }
        }
        
}   




}

